const API_URL = 'http://localhost:3000/api';

const formLogin = document.getElementById('formLogin');
const mensagemDiv = document.getElementById('mensagem');

function mostrarMensagem(texto, tipo) {
    mensagemDiv.textContent = texto;
    mensagemDiv.className = tipo === 'sucesso' ? 'mensagem sucesso' : 'mensagem erro';
    mensagemDiv.classList.remove('escondido');
}

formLogin.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    if (!email || !senha) {
        mostrarMensagem('Preencha todos os campos!', 'erro');
        return;
    }

    // Login com credenciais de administrador (offline)
    if (email === 'adm' && senha === 'adm') {
        localStorage.setItem('usuario', JSON.stringify({
            id_usuario: 0,
            nome: 'Administrador',
            email: 'adm',
            isAdmin: true
        }));
        mostrarMensagem('Login realizado com sucesso!', 'sucesso');
        setTimeout(() => {
            window.location.href = 'feed.html';
        }, 1000);
        return;
    }

    // Login via API
    try {
        const response = await fetch(`${API_URL}/usuarios/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, senha })
        });

        const data = await response.json();

        if (response.ok && data.sucesso) {
            // Salvar usuario no localStorage
            localStorage.setItem('usuario', JSON.stringify({
                ...data.usuario,
                isAdmin: false
            }));
            
            mostrarMensagem('Login realizado com sucesso!', 'sucesso');
            
            setTimeout(() => {
                window.location.href = 'feed.html';
            }, 1000);
        } else {
            mostrarMensagem(data.erro || 'Email ou senha incorretos', 'erro');
        }
    } catch (erro) {
        console.error('Erro no login:', erro);
        mostrarMensagem('Erro ao conectar com servidor. Verifique se o backend esta rodando.', 'erro');
    }
});
