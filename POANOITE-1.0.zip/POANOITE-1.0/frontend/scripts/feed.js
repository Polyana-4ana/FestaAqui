const API_URL = 'http://localhost:3000/api';
const IMAGEM_PADRAO = '../imagens/evento-padrao.svg';

let posts = [];
let postsFiltrados = [];
let postExpandidoId = null;

// Verificar se usuario esta logado
const usuario = JSON.parse(localStorage.getItem('usuario') || '{}');
if (!usuario.id_usuario && !usuario.isAdmin) {
    window.location.href = 'login.html';
}

function irPara(pagina) {
    window.location.href = pagina;
}

function abrirPerfilEstabelecimento(estabelecimentoId, estabelecimentoNome) {
    localStorage.setItem('estabelecimentoId', estabelecimentoId);
    localStorage.setItem('estabelecimentoNome', estabelecimentoNome);
    window.location.href = 'perfil-estabelecimento.html';
}

async function expandirPost(postId) {
    if (postExpandidoId === postId) {
        postExpandidoId = null;
    } else {
        postExpandidoId = postId;
    }
    await renderizarPosts();
}

function formatarData(dataISO) {
    const data = new Date(dataISO);
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const hora = String(data.getHours()).padStart(2, '0');
    const minuto = String(data.getMinutes()).padStart(2, '0');
    
    return `${dia}/${mes} - ${hora}:${minuto}h`;
}

async function curtirPost(postId) {
    if (!usuario.id_usuario) {
        alert('Faca login para curtir posts');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/posts/${postId}/curtir`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_usuario: usuario.id_usuario
            })
        });

        if (response.ok) {
            await carregarPosts();
        }
    } catch (erro) {
        console.error('Erro ao curtir:', erro);
    }
}

async function comentarPost(postId) {
    const comentarioTexto = document.getElementById(`comentario-${postId}`).value.trim();
    
    if (!comentarioTexto) {
        alert('Digite um comentario');
        return;
    }

    if (!usuario.id_usuario) {
        alert('Faca login para comentar');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/comentarios`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_postagem: postId,
                id_usuario: usuario.id_usuario,
                comentario: comentarioTexto
            })
        });

        if (response.ok) {
            document.getElementById(`comentario-${postId}`).value = '';
            await expandirPost(postId);
        }
    } catch (erro) {
        console.error('Erro ao comentar:', erro);
    }
}

async function carregarComentarios(postId) {
    try {
        const response = await fetch(`${API_URL}/comentarios/post/${postId}`);
        const comentarios = await response.json();
        return comentarios;
    } catch (erro) {
        console.error('Erro ao carregar comentarios:', erro);
        return [];
    }
}

async function renderizarPosts() {
    const listaPosts = document.getElementById('listaPosts');
    listaPosts.innerHTML = '';

    if (postsFiltrados.length === 0) {
        listaPosts.innerHTML = '<p class="centro" style="color: #999;">Nenhum evento encontrado</p>';
        return;
    }

    for (const post of postsFiltrados) {
        const isExpandido = postExpandidoId === post.id_postagem;
        
        // Usar imagem padrão se não tiver foto
        const imagemUrl = post.foto_url || IMAGEM_PADRAO;
        
        let comentariosHTML = '';
        if (isExpandido) {
            const comentarios = await carregarComentarios(post.id_postagem);
            
            if (comentarios.length > 0) {
                comentariosHTML = '<div style="margin-top: 20px; border-top: 1px solid #333; padding-top: 16px;"><h4 style="margin-bottom: 12px;">Comentarios:</h4>';
                comentarios.forEach(c => {
                    comentariosHTML += `
                        <div style="background: #1a1a1a; padding: 12px; border-radius: 10px; margin-bottom: 8px;">
                            <strong>${c.nome} ${c.sobrenome}</strong>
                            <p style="color: #ccc; margin-top: 4px;">${c.comentario}</p>
                        </div>
                    `;
                });
                comentariosHTML += '</div>';
            }
        }
        
        const postDiv = document.createElement('div');
        postDiv.className = isExpandido ? 'post post-expandido' : 'post';
        
        postDiv.innerHTML = `
            <img src="${imagemUrl}" alt="${post.estabelecimento_nome}" onclick="expandirPost(${post.id_postagem})" onerror="this.src='${IMAGEM_PADRAO}'">
            <div class="post-info">
                <h3 class="post-titulo post-titulo-link" onclick="abrirPerfilEstabelecimento(${post.id_estabelecimento}, '${post.estabelecimento_nome}')">
                    ${post.estabelecimento_nome}
                </h3>
                <p class="post-descricao ${isExpandido ? 'post-descricao-completa' : ''}">
                    ${post.descricao}
                </p>
                <p class="post-data">${formatarData(post.horario_evento)}</p>
                <p class="post-curtidas">${post.curtidas} curtidas</p>
                ${isExpandido ? `
                    ${comentariosHTML}
                    <div style="margin-top: 16px;">
                        <textarea id="comentario-${post.id_postagem}" placeholder="Escreva um comentario..." rows="2" style="margin-bottom: 8px;"></textarea>
                        <button class="btn btn-primary" onclick="comentarPost(${post.id_postagem})" style="margin-right: 8px;">
                            Comentar
                        </button>
                        <button class="btn btn-primary" onclick="curtirPost(${post.id_postagem})" style="margin-right: 8px;">
                            Curtir
                        </button>
                        <button class="btn btn-secondary" onclick="expandirPost(${post.id_postagem})">
                            Fechar
                        </button>
                    </div>
                ` : ''}
            </div>
        `;
        
        listaPosts.appendChild(postDiv);
    }
}

function pesquisarCasas() {
    const termoPesquisa = document.getElementById('inputPesquisa').value.toLowerCase();
    
    if (termoPesquisa === '') {
        postsFiltrados = [...posts];
    } else {
        postsFiltrados = posts.filter(post => 
            post.estabelecimento_nome.toLowerCase().includes(termoPesquisa)
        );
    }
    
    renderizarPosts();
}

async function carregarPosts() {
    try {
        const response = await fetch(`${API_URL}/posts`);
        const data = await response.json();
        
        posts = data;
        postsFiltrados = [...posts];
        await renderizarPosts();
    } catch (erro) {
        console.error('Erro ao carregar posts:', erro);
        document.getElementById('listaPosts').innerHTML = 
            '<p class="centro" style="color: #ff0044;">Erro ao carregar eventos. Verifique se o backend esta rodando.</p>';
    }
}

// Carregar posts ao iniciar
carregarPosts();
