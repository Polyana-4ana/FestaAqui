const API_URL = 'http://localhost:3000/api';

function irPara(pagina) {
    window.location.href = pagina;
}

function formatarData(dataISO) {
    const data = new Date(dataISO);
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0');
    const hora = String(data.getHours()).padStart(2, '0');
    const minuto = String(data.getMinutes()).padStart(2, '0');
    
    return `${dia}/${mes} - ${hora}:${minuto}h`;
}

window.onload = async function() {
    const estabelecimentoId = localStorage.getItem('estabelecimentoId');
    const estabelecimentoNome = localStorage.getItem('estabelecimentoNome');
    
    if (!estabelecimentoId) {
        window.location.href = 'feed.html';
        return;
    }
    
    try {
        // Buscar dados do estabelecimento
        const responseEstab = await fetch(`${API_URL}/estabelecimentos/${estabelecimentoId}`);
        const estabelecimento = await responseEstab.json();
        
        if (responseEstab.ok) {
            document.getElementById('estabelecimentoNome').textContent = estabelecimento.nome;
            document.getElementById('estabelecimentoDescricao').textContent = estabelecimento.descricao || 'Sem descricao';
        }
        
        // Buscar todos os posts
        const responsePosts = await fetch(`${API_URL}/posts`);
        const todosPosts = await responsePosts.json();
        
        // Filtrar posts deste estabelecimento
        const eventosEstabelecimento = todosPosts.filter(
            post => post.id_estabelecimento == estabelecimentoId
        );
        
        const listaEventos = document.getElementById('eventosEstabelecimento');
        
        if (eventosEstabelecimento.length === 0) {
            listaEventos.innerHTML = '<p class="centro" style="color: #999;">Nenhum evento cadastrado ainda</p>';
            return;
        }
        
        eventosEstabelecimento.forEach(post => {
            const postDiv = document.createElement('div');
            postDiv.className = 'post';
            postDiv.innerHTML = `
                <img src="${post.foto_url}" alt="${estabelecimento.nome}">
                <div class="post-info">
                    <p class="post-descricao">${post.descricao}</p>
                    <p class="post-data">${formatarData(post.horario_evento)}</p>
                    <p class="post-curtidas">${post.curtidas} curtidas</p>
                </div>
            `;
            listaEventos.appendChild(postDiv);
        });
        
    } catch (erro) {
        console.error('Erro ao carregar estabelecimento:', erro);
        document.getElementById('eventosEstabelecimento').innerHTML = 
            '<p class="centro" style="color: #ff0044;">Erro ao carregar dados. Verifique se o backend esta rodando.</p>';
    }
};
