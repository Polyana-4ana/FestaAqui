const API_URL = 'http://localhost:3000/api';

// Verificar se usuario esta logado
const usuario = JSON.parse(localStorage.getItem('usuario') || '{}');
if (!usuario.id_usuario && !usuario.isAdmin) {
    window.location.href = 'login.html';
}

function irPara(pagina) {
    window.location.href = pagina;
}

// Carregar estabelecimentos
async function carregarEstabelecimentos() {
    try {
        const response = await fetch(`${API_URL}/estabelecimentos`);
        const estabelecimentos = await response.json();
        
        const select = document.getElementById('estabelecimento');
        select.innerHTML = '<option value="">Selecione um estabelecimento</option>';
        
        estabelecimentos.forEach(estab => {
            const option = document.createElement('option');
            option.value = estab.id_estabelecimento;
            option.textContent = estab.nome;
            select.appendChild(option);
        });
    } catch (erro) {
        console.error('Erro ao carregar estabelecimentos:', erro);
    }
}

// Criar post
document.getElementById('formPost').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const id_estabelecimento = document.getElementById('estabelecimento').value;
    const descricao = document.getElementById('descricao').value;
    const foto_url = document.getElementById('fotoUrl').value || null; // Foto opcional
    const horario_evento = document.getElementById('horario').value;
    
    if (!id_estabelecimento || !descricao || !horario_evento) {
        alert('Preencha estabelecimento, descricao e horario!');
        return;
    }
    
    if (!usuario.id_usuario) {
        alert('Faca login para criar posts');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/posts`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_usuario: usuario.id_usuario,
                id_estabelecimento,
                foto_url,
                descricao,
                horario_evento
            })
        });
        
        const data = await response.json();
        
        if (response.ok && data.sucesso) {
            alert('Post criado com sucesso!');
            window.location.href = 'feed.html';
        } else {
            alert(data.erro || 'Erro ao criar post');
        }
    } catch (erro) {
        console.error('Erro ao criar post:', erro);
        alert('Erro ao conectar com servidor. Verifique se o backend esta rodando.');
    }
});

// Carregar estabelecimentos ao iniciar
carregarEstabelecimentos();
