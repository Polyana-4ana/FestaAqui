const API_URL = 'http://localhost:3000/api';

const formCadastro = document.getElementById('formCadastro');
const mensagemDiv = document.getElementById('mensagem');

function mostrarMensagem(texto, tipo) {
    mensagemDiv.textContent = texto;
    mensagemDiv.className = tipo === 'sucesso' ? 'mensagem sucesso' : 'mensagem erro';
    mensagemDiv.classList.remove('escondido');
}

formCadastro.addEventListener('submit', async (e) => {
    e.preventDefault();

    const nome = document.getElementById('nome').value;
    const sobrenome = document.getElementById('sobrenome').value;
    const cpf = document.getElementById('cpf').value;
    const email = document.getElementById('email').value;
    const telefone = document.getElementById('telefone').value;
    const senha = document.getElementById('senha').value;

    // Validacoes
    if (cpf.length !== 11) {
        mostrarMensagem('CPF deve ter 11 digitos', 'erro');
        return;
    }

    if (senha.length < 4) {
        mostrarMensagem('Senha deve ter pelo menos 4 caracteres', 'erro');
        return;
    }

    try {
        const response = await fetch(`${API_URL}/usuarios/cadastro`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome,
                sobrenome,
                cpf,
                email,
                telefone,
                senha
            })
        });

        const data = await response.json();

        if (response.ok && data.sucesso) {
            mostrarMensagem('Conta criada com sucesso!', 'sucesso');
            
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1500);
        } else {
            mostrarMensagem(data.erro || 'Erro ao criar conta', 'erro');
        }
    } catch (erro) {
        console.error('Erro no cadastro:', erro);
        mostrarMensagem('Erro ao conectar com servidor. Verifique se o backend esta rodando.', 'erro');
    }
});
