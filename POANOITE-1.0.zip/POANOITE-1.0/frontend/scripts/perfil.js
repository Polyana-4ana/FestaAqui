const API_URL = 'http://localhost:3000/api';

function irPara(pagina) {
    window.location.href = pagina;
}

// Carregar dados do usuario
window.onload = async function() {
    console.log('Perfil carregando...');
    
    const usuario = JSON.parse(localStorage.getItem('usuario') || '{}');
    console.log('Usuario do localStorage:', usuario);
    
    if (!usuario.id_usuario && !usuario.isAdmin) {
        console.log('Usuario nao logado, redirecionando...');
        window.location.href = 'login.html';
        return;
    }
    
    // Se for usuario real, buscar dados atualizados da API
    if (usuario.id_usuario && !usuario.isAdmin) {
        try {
            console.log('Buscando dados da API...');
            const response = await fetch(`${API_URL}/usuarios/${usuario.id_usuario}`);
            
            if (response.ok) {
                const data = await response.json();
                console.log('Dados da API:', data);
                
                const nomeCompleto = `${data.nome} ${data.sobrenome}`;
                document.getElementById('perfilNome').textContent = nomeCompleto;
                document.getElementById('perfilEmail').textContent = data.email;
                
                // Atualizar localStorage
                localStorage.setItem('usuario', JSON.stringify({
                    ...usuario,
                    nome: data.nome,
                    sobrenome: data.sobrenome,
                    email: data.email
                }));
                
                console.log('Perfil atualizado com sucesso!');
            } else {
                console.log('Erro na API, usando dados do localStorage');
                const nomeCompleto = usuario.sobrenome ? `${usuario.nome} ${usuario.sobrenome}` : usuario.nome;
                document.getElementById('perfilNome').textContent = nomeCompleto || 'Usuario';
                document.getElementById('perfilEmail').textContent = usuario.email || '';
            }
        } catch (erro) {
            console.error('Erro ao carregar perfil:', erro);
            // Usar dados do localStorage se der erro
            const nomeCompleto = usuario.sobrenome ? `${usuario.nome} ${usuario.sobrenome}` : usuario.nome;
            document.getElementById('perfilNome').textContent = nomeCompleto || 'Usuario';
            document.getElementById('perfilEmail').textContent = usuario.email || '';
        }
    } else {
        // Usuario admin
        console.log('Usuario admin');
        document.getElementById('perfilNome').textContent = usuario.nome || 'Administrador';
        document.getElementById('perfilEmail').textContent = usuario.email || 'adm';
    }
    
    console.log('Perfil carregado completamente!');
};

function editarPerfil() {
    const usuario = JSON.parse(localStorage.getItem('usuario') || '{}');
    
    const nomeCompleto = document.getElementById('perfilNome').textContent.split(' ');
    const nome = nomeCompleto[0] || '';
    const sobrenome = nomeCompleto.slice(1).join(' ') || '';
    
    document.getElementById('editNome').value = nome;
    document.getElementById('editSobrenome').value = sobrenome;
    document.getElementById('editEmail').value = document.getElementById('perfilEmail').textContent;
    
    document.getElementById('perfilInfo').classList.add('escondido');
    document.getElementById('perfilEdit').classList.remove('escondido');
}

async function salvarPerfil() {
    const usuario = JSON.parse(localStorage.getItem('usuario') || '{}');
    
    const nome = document.getElementById('editNome').value;
    const sobrenome = document.getElementById('editSobrenome').value;
    const email = document.getElementById('editEmail').value;
    
    if (!nome || !sobrenome || !email) {
        alert('Preencha todos os campos!');
        return;
    }
    
    // Se for usuario real, atualizar via API
    if (usuario.id_usuario && !usuario.isAdmin) {
        try {
            const response = await fetch(`${API_URL}/usuarios/${usuario.id_usuario}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ nome, sobrenome, email })
            });

            const data = await response.json();

            if (response.ok && data.sucesso) {
                usuario.nome = nome;
                usuario.sobrenome = sobrenome;
                usuario.email = email;
                
                localStorage.setItem('usuario', JSON.stringify(usuario));
                
                document.getElementById('perfilNome').textContent = `${nome} ${sobrenome}`;
                document.getElementById('perfilEmail').textContent = email;
                
                alert('Perfil atualizado com sucesso!');
            } else {
                alert(data.erro || 'Erro ao atualizar perfil');
                return;
            }
        } catch (erro) {
            console.error('Erro ao salvar perfil:', erro);
            alert('Erro ao conectar com servidor');
            return;
        }
    } else {
        // Usuario admin - salvar apenas no localStorage
        usuario.nome = `${nome} ${sobrenome}`;
        usuario.email = email;
        
        localStorage.setItem('usuario', JSON.stringify(usuario));
        
        document.getElementById('perfilNome').textContent = `${nome} ${sobrenome}`;
        document.getElementById('perfilEmail').textContent = email;
        
        alert('Perfil atualizado com sucesso!');
    }
    
    document.getElementById('perfilInfo').classList.remove('escondido');
    document.getElementById('perfilEdit').classList.add('escondido');
}

function cancelarEdicao() {
    document.getElementById('perfilInfo').classList.remove('escondido');
    document.getElementById('perfilEdit').classList.add('escondido');
}
