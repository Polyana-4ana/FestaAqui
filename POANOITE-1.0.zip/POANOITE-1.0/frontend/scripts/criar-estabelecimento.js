const API_URL = 'http://localhost:3000/api';

// Verificar se usuario esta logado
const usuario = JSON.parse(localStorage.getItem('usuario') || '{}');
if (!usuario.id_usuario && !usuario.isAdmin) {
    window.location.href = 'login.html';
}

function voltar() {
    window.location.href = 'criar-post.html';
}

document.getElementById('formEstabelecimento').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const nome = document.getElementById('nome').value;
    const descricao = document.getElementById('descricao').value;
    
    if (!nome || !descricao) {
        alert('Preencha nome e descricao!');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/estabelecimentos`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nome,
                descricao
            })
        });
        
        const data = await response.json();
        
        if (response.ok && data.sucesso) {
            alert('Estabelecimento criado com sucesso!');
            window.location.href = 'criar-post.html';
        } else {
            alert(data.erro || 'Erro ao criar estabelecimento');
        }
    } catch (erro) {
        console.error('Erro ao criar estabelecimento:', erro);
        alert('Erro ao conectar com servidor. Verifique se o backend esta rodando.');
    }
});
