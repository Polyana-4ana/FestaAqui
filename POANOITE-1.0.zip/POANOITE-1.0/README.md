# PO A NOITE - VERSAO CORRIGIDA

Projeto completo com todas as correcoes solicitadas

---

## CORRECOES IMPLEMENTADAS

1. Perfil agora funciona corretamente (nao esconde mais a sidebar)
2. Configuracoes > Editar Perfil redireciona para a pagina de perfil
3. Configuracoes > Suporte abre modal para enviar mensagem
4. Imagem padrao para eventos sem foto
5. Eventos ordenados por numero de curtidas
6. Titulo "Feed de Eventos" centralizado
7. Banco de dados simplificado (removido tabela de enderecos)
8. Cadastro simplificado (sem endereco)
9. Foto opcional ao criar eventos

---

## BANCO DE DADOS SIMPLIFICADO

Tabelas:
- usuarios (sem referencia a endereco)
- estabelecimentos (campo google_place_id removido)
- eventos_postagens (foto_url pode ser NULL)
- curtidas_postagens
- usuario_comentarios

---

## INSTALACAO

### 1. Backend
```bash
cd backend
npm install
```

### 2. PostgreSQL

**Criar banco:**
```sql
CREATE DATABASE poanoite;
```

**No pgAdmin, executar:**
1. criar_tabelas.sql
2. dados_teste.sql

### 3. Iniciar backend
```bash
npm start
```

### 4. Frontend
Abrir: frontend/paginas/login.html

---

## DADOS DE TESTE

### Usuarios:
- joao@gmail.com / 1234
- maria@gmail.com / 1234
- pedro@gmail.com / 1234

### Admin:
- adm / adm

### Estabelecimentos:
- Poaclub
- Dance Night
- Sunset Lounge
- After Hours

### Posts:
5 eventos (alguns com foto, outros com imagem padrao)

---

## FUNCIONALIDADES

- Login / Cadastro simplificado
- Feed ordenado por curtidas
- Imagem padrao quando evento nao tem foto
- Comentarios em posts
- Curtir eventos
- Criar posts (foto opcional)
- Criar estabelecimentos
- Editar perfil (admin)
- Modal de suporte nas configuracoes
- Pesquisar casas de festa

---

## IMPORTANTE

O backend DEVE estar rodando:
```bash
cd backend
npm start
```

Deixe o terminal aberto!

---

Tudo funcionando 100%!
