-- BANCO DE DADOS SIMPLIFICADO - PO A NOITE

-- Tabela de Usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    sobrenome VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    senha VARCHAR(255) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Estabelecimentos
CREATE TABLE IF NOT EXISTS estabelecimentos (
    id_estabelecimento SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Eventos/Postagens
CREATE TABLE IF NOT EXISTS eventos_postagens (
    id_postagem SERIAL PRIMARY KEY,
    id_usuario INTEGER REFERENCES usuarios(id_usuario),
    id_estabelecimento INTEGER REFERENCES estabelecimentos(id_estabelecimento),
    foto_url TEXT,
    descricao TEXT NOT NULL,
    horario_evento TIMESTAMP NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Curtidas
CREATE TABLE IF NOT EXISTS curtidas_postagens (
    id_curtida SERIAL PRIMARY KEY,
    id_postagem INTEGER REFERENCES eventos_postagens(id_postagem) ON DELETE CASCADE,
    id_usuario INTEGER REFERENCES usuarios(id_usuario),
    data_curtida TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(id_postagem, id_usuario)
);

-- Tabela de Comentarios
CREATE TABLE IF NOT EXISTS usuario_comentarios (
    id_comentario SERIAL PRIMARY KEY,
    id_postagem INTEGER REFERENCES eventos_postagens(id_postagem) ON DELETE CASCADE,
    id_usuario INTEGER REFERENCES usuarios(id_usuario),
    comentario TEXT NOT NULL,
    data_comentario TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Criar indices para melhorar performance
CREATE INDEX IF NOT EXISTS idx_posts_usuario ON eventos_postagens(id_usuario);
CREATE INDEX IF NOT EXISTS idx_posts_estabelecimento ON eventos_postagens(id_estabelecimento);
CREATE INDEX IF NOT EXISTS idx_curtidas_post ON curtidas_postagens(id_postagem);
CREATE INDEX IF NOT EXISTS idx_comentarios_post ON usuario_comentarios(id_postagem);
