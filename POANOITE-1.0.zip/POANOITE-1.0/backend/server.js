const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Rotas
const usuariosRoutes = require('./routes/usuarios');
const estabelecimentosRoutes = require('./routes/estabelecimentos');
const postsRoutes = require('./routes/posts');
const comentariosRoutes = require('./routes/comentarios');

app.use('/api/usuarios', usuariosRoutes);
app.use('/api/estabelecimentos', estabelecimentosRoutes);
app.use('/api/posts', postsRoutes);
app.use('/api/comentarios', comentariosRoutes);

// Rota raiz
app.get('/', (req, res) => {
    res.json({ 
        mensagem: 'API Po a Noite funcionando',
        versao: '1.0.0'
    });
});

// Iniciar servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
    console.log(`http://localhost:${PORT}`);
});
