const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// LISTAR COMENTARIOS DE UM POST
router.get('/post/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const resultado = await pool.query(`
            SELECT 
                c.id_comentario,
                c.comentario,
                c.data_comentario,
                u.id_usuario,
                u.nome,
                u.sobrenome
            FROM usuario_comentarios c
            JOIN usuarios u ON c.id_usuario = u.id_usuario
            WHERE c.id_postagem = $1
            ORDER BY c.data_comentario DESC
        `, [id]);

        res.json(resultado.rows);
    } catch (erro) {
        console.error('Erro ao listar comentarios:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// ADICIONAR COMENTARIO
router.post('/', async (req, res) => {
    try {
        const { id_postagem, id_usuario, comentario } = req.body;

        const resultado = await pool.query(
            'INSERT INTO usuario_comentarios (id_postagem, id_usuario, comentario) VALUES ($1, $2, $3) RETURNING *',
            [id_postagem, id_usuario, comentario]
        );

        res.json({
            sucesso: true,
            comentario: resultado.rows[0]
        });
    } catch (erro) {
        console.error('Erro ao adicionar comentario:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// DELETAR COMENTARIO
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        await pool.query('DELETE FROM usuario_comentarios WHERE id_comentario = $1', [id]);

        res.json({ sucesso: true });
    } catch (erro) {
        console.error('Erro ao deletar comentario:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

module.exports = router;
