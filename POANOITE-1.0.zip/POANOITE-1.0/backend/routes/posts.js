const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// LISTAR TODOS (FEED) - Eventos futuros primeiro, depois passados, ordenados por curtidas
router.get('/', async (req, res) => {
    try {
        const resultado = await pool.query(`
            SELECT 
                p.id_postagem,
                p.foto_url,
                p.descricao,
                p.horario_evento,
                p.data_criacao,
                e.id_estabelecimento,
                e.nome as estabelecimento_nome,
                u.id_usuario,
                u.nome as usuario_nome,
                (SELECT COUNT(*) FROM curtidas_postagens WHERE id_postagem = p.id_postagem) as curtidas,
                CASE 
                    WHEN p.horario_evento >= NOW() THEN 0
                    ELSE 1
                END as evento_passado
            FROM eventos_postagens p
            JOIN estabelecimentos e ON p.id_estabelecimento = e.id_estabelecimento
            JOIN usuarios u ON p.id_usuario = u.id_usuario
            ORDER BY evento_passado ASC, curtidas DESC, p.data_criacao DESC
        `);

        res.json(resultado.rows);
    } catch (erro) {
        console.error('Erro ao listar posts:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// BUSCAR POR ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const resultado = await pool.query(`
            SELECT 
                p.*,
                e.nome as estabelecimento_nome,
                u.nome as usuario_nome,
                (SELECT COUNT(*) FROM curtidas_postagens WHERE id_postagem = p.id_postagem) as curtidas
            FROM eventos_postagens p
            JOIN estabelecimentos e ON p.id_estabelecimento = e.id_estabelecimento
            JOIN usuarios u ON p.id_usuario = u.id_usuario
            WHERE p.id_postagem = $1
        `, [id]);

        if (resultado.rows.length === 0) {
            return res.status(404).json({ erro: 'Post nao encontrado' });
        }

        res.json(resultado.rows[0]);
    } catch (erro) {
        console.error('Erro ao buscar post:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// CRIAR POST
router.post('/', async (req, res) => {
    try {
        const { id_usuario, id_estabelecimento, foto_url, descricao, horario_evento } = req.body;

        const resultado = await pool.query(
            'INSERT INTO eventos_postagens (id_usuario, id_estabelecimento, foto_url, descricao, horario_evento) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [id_usuario, id_estabelecimento, foto_url, descricao, horario_evento]
        );

        res.json({
            sucesso: true,
            post: resultado.rows[0]
        });
    } catch (erro) {
        console.error('Erro ao criar post:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// CURTIR POST
router.post('/:id/curtir', async (req, res) => {
    try {
        const { id } = req.params;
        const { id_usuario } = req.body;

        // Verificar se já curtiu
        const jaExiste = await pool.query(
            'SELECT * FROM curtidas_postagens WHERE id_postagem = $1 AND id_usuario = $2',
            [id, id_usuario]
        );

        if (jaExiste.rows.length > 0) {
            // Descurtir
            await pool.query(
                'DELETE FROM curtidas_postagens WHERE id_postagem = $1 AND id_usuario = $2',
                [id, id_usuario]
            );
            res.json({ sucesso: true, curtiu: false });
        } else {
            // Curtir
            await pool.query(
                'INSERT INTO curtidas_postagens (id_postagem, id_usuario) VALUES ($1, $2)',
                [id, id_usuario]
            );
            res.json({ sucesso: true, curtiu: true });
        }
    } catch (erro) {
        console.error('Erro ao curtir:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

module.exports = router;
