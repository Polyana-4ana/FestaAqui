const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// LISTAR TODOS
router.get('/', async (req, res) => {
    try {
        const resultado = await pool.query(
            'SELECT * FROM estabelecimentos ORDER BY nome'
        );

        res.json(resultado.rows);
    } catch (erro) {
        console.error('Erro ao listar estabelecimentos:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// BUSCAR POR ID
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const resultado = await pool.query(
            'SELECT * FROM estabelecimentos WHERE id_estabelecimento = $1',
            [id]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({ erro: 'Estabelecimento nao encontrado' });
        }

        res.json(resultado.rows[0]);
    } catch (erro) {
        console.error('Erro ao buscar estabelecimento:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// CRIAR
router.post('/', async (req, res) => {
    try {
        const { nome, descricao } = req.body;

        if (!nome || !descricao) {
            return res.status(400).json({ erro: 'Nome e descricao sao obrigatorios' });
        }

        const resultado = await pool.query(
            'INSERT INTO estabelecimentos (nome, descricao) VALUES ($1, $2) RETURNING *',
            [nome, descricao]
        );

        res.json({
            sucesso: true,
            estabelecimento: resultado.rows[0]
        });
    } catch (erro) {
        console.error('Erro ao criar estabelecimento:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

module.exports = router;
