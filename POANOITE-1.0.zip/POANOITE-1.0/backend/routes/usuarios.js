const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// LOGIN
router.post('/login', async (req, res) => {
    try {
        const { email, senha } = req.body;

        const resultado = await pool.query(
            'SELECT id_usuario, nome, sobrenome, email FROM usuarios WHERE email = $1 AND senha = $2',
            [email, senha]
        );

        if (resultado.rows.length === 0) {
            return res.status(401).json({ erro: 'Email ou senha incorretos' });
        }

        res.json({ 
            sucesso: true,
            usuario: resultado.rows[0]
        });
    } catch (erro) {
        console.error('Erro no login:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// CADASTRO
router.post('/cadastro', async (req, res) => {
    try {
        const { nome, sobrenome, cpf, email, telefone, senha } = req.body;

        // Inserir usuário
        const usuarioResult = await pool.query(
            'INSERT INTO usuarios (nome, sobrenome, cpf, email, telefone, senha) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id_usuario, nome, sobrenome, email',
            [nome, sobrenome, cpf, email, telefone, senha]
        );

        res.json({
            sucesso: true,
            usuario: usuarioResult.rows[0]
        });
    } catch (erro) {
        console.error('Erro no cadastro:', erro);
        res.status(500).json({ erro: 'Erro ao criar conta' });
    }
});

// BUSCAR PERFIL
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const resultado = await pool.query(
            'SELECT id_usuario, nome, sobrenome, email, telefone FROM usuarios WHERE id_usuario = $1',
            [id]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({ erro: 'Usuario nao encontrado' });
        }

        res.json(resultado.rows[0]);
    } catch (erro) {
        console.error('Erro ao buscar perfil:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

// ATUALIZAR PERFIL
router.put('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { nome, sobrenome, email } = req.body;

        const resultado = await pool.query(
            'UPDATE usuarios SET nome = $1, sobrenome = $2, email = $3 WHERE id_usuario = $4 RETURNING id_usuario, nome, sobrenome, email',
            [nome, sobrenome, email, id]
        );

        if (resultado.rows.length === 0) {
            return res.status(404).json({ erro: 'Usuario nao encontrado' });
        }

        res.json({
            sucesso: true,
            usuario: resultado.rows[0]
        });
    } catch (erro) {
        console.error('Erro ao atualizar perfil:', erro);
        res.status(500).json({ erro: 'Erro no servidor' });
    }
});

module.exports = router;
