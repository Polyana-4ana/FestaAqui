-- DADOS DE TESTE - PO A NOITE

-- Limpar dados antigos
DELETE FROM usuario_comentarios;
DELETE FROM curtidas_postagens;
DELETE FROM eventos_postagens;
DELETE FROM estabelecimentos;
DELETE FROM usuarios;

-- Reiniciar sequencias
ALTER SEQUENCE usuarios_id_usuario_seq RESTART WITH 1;
ALTER SEQUENCE estabelecimentos_id_estabelecimento_seq RESTART WITH 1;
ALTER SEQUENCE eventos_postagens_id_postagem_seq RESTART WITH 1;
ALTER SEQUENCE curtidas_postagens_id_curtida_seq RESTART WITH 1;
ALTER SEQUENCE usuario_comentarios_id_comentario_seq RESTART WITH 1;

-- Inserir usuarios (senha: 1234 para todos)
INSERT INTO usuarios (nome, sobrenome, cpf, email, telefone, senha) VALUES
('Joao', 'Silva', '12345678901', 'joao@gmail.com', '54999999999', '1234'),
('Maria', 'Santos', '98765432101', 'maria@gmail.com', '54988888888', '1234'),
('Pedro', 'Oliveira', '11122233344', 'pedro@gmail.com', '54977777777', '1234');

-- Inserir estabelecimentos
INSERT INTO estabelecimentos (nome, descricao) VALUES
('Poaclub', 'A melhor casa noturna da cidade com DJs internacionais e ambiente incrivel.'),
('Dance Night', 'Musica eletronica de qualidade e pista de danca ampla para voce curtir a noite.'),
('Sunset Lounge', 'Bar sofisticado com drinks autorais, perfeito para comecar sua noite.'),
('After Hours', 'O melhor after da cidade. A festa nao para ate o sol nascer.');

-- Inserir posts (alguns com foto, outros sem - foto_url pode ser NULL)
INSERT INTO eventos_postagens (id_usuario, id_estabelecimento, foto_url, descricao, horario_evento) VALUES
(1, 1, 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=1200', 'Uma noite inesquecivel com os melhores DJs da cidade. Musica eletronica, drinks especiais e ambiente incrivel.', '2024-12-23 22:00:00'),
(2, 2, NULL, 'DJ Set especial com os maiores sucessos do momento. Venha dancar ate o amanhecer com a gente.', '2024-12-25 23:00:00'),
(3, 3, 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=1200', 'Bar sofisticado com drinks autorais e vista privilegiada. O lugar perfeito para comecar sua noite.', '2024-12-27 20:00:00'),
(1, 4, NULL, 'O melhor after da cidade. Musica boa, gente bonita e a festa nao para ate o sol nascer.', '2024-12-28 04:00:00'),
(2, 1, 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=1200', 'Festa tematica anos 80! Vista-se a carater e venha curtir os classicos.', '2024-12-29 21:00:00');

-- Inserir curtidas (mais curtidas nos primeiros posts)
INSERT INTO curtidas_postagens (id_postagem, id_usuario) VALUES
(1, 1), (1, 2), (1, 3),
(2, 2), (2, 3),
(3, 1), (3, 3),
(4, 1),
(5, 1), (5, 2), (5, 3);

-- Inserir alguns comentarios
INSERT INTO usuario_comentarios (id_postagem, id_usuario, comentario) VALUES
(1, 2, 'Vai estar incrivel! Ja confirmei presenca'),
(1, 3, 'Alguem tem convite extra?'),
(3, 1, 'Melhor bar da cidade mesmo'),
(5, 2, 'Amo festas anos 80!');

-- Verificar dados inseridos
SELECT 'Setup completo!' as status;
SELECT COUNT(*) as total_usuarios FROM usuarios;
SELECT COUNT(*) as total_estabelecimentos FROM estabelecimentos;
SELECT COUNT(*) as total_posts FROM eventos_postagens;
SELECT COUNT(*) as total_curtidas FROM curtidas_postagens;
SELECT COUNT(*) as total_comentarios FROM usuario_comentarios;
